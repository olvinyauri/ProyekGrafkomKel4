﻿using LearnOpenTK.Common;
using OpenTK.Windowing.Desktop;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Windowing.GraphicsLibraryFramework;
using System;
using System.Collections.Generic;
using System.Text;
using OpenTK.Windowing.Common;
using OpenTK.Mathematics;

namespace latihan1
{

    class window : GameWindow
    {

        List<Vector3> _Vertices = new List<Vector3>();

        //asset3d[] _object3d = new asset3d[20]; // Baymax
        //asset3d[] weapon = new asset3d[5];
        //asset3d[] object3d = new asset3d[20]; // Bad piggies
        //asset3d[] __object3d = new asset3d[20]; // Minion
        asset3d[] park = new asset3d[10]; // Park

        //int ctr = 0;
        //int counter = 0;

        float[] _vertices =
         {
            // Position
            -0.5f, -0.5f, -0.5f, // Front face
             0.5f, -0.5f, -0.5f,
             0.5f,  0.5f, -0.5f,
             0.5f,  0.5f, -0.5f,
            -0.5f,  0.5f, -0.5f,
            -0.5f, -0.5f, -0.5f,

            -0.5f, -0.5f,  0.5f, // Back face
             0.5f, -0.5f,  0.5f,
             0.5f,  0.5f,  0.5f,
             0.5f,  0.5f,  0.5f,
            -0.5f,  0.5f,  0.5f,
            -0.5f, -0.5f,  0.5f,

            -0.5f,  0.5f,  0.5f, // Left face
            -0.5f,  0.5f, -0.5f,
            -0.5f, -0.5f, -0.5f,
            -0.5f, -0.5f, -0.5f,
            -0.5f, -0.5f,  0.5f,
            -0.5f,  0.5f,  0.5f,

             0.5f,  0.5f,  0.5f, // Right face
             0.5f,  0.5f, -0.5f,
             0.5f, -0.5f, -0.5f,
             0.5f, -0.5f, -0.5f,
             0.5f, -0.5f,  0.5f,
             0.5f,  0.5f,  0.5f,

            -0.5f, -0.5f, -0.5f, // Bottom face
             0.5f, -0.5f, -0.5f,
             0.5f, -0.5f,  0.5f,
             0.5f, -0.5f,  0.5f,
            -0.5f, -0.5f,  0.5f,
            -0.5f, -0.5f, -0.5f,

            -0.5f,  0.5f, -0.5f, // Top face
             0.5f,  0.5f, -0.5f,
             0.5f,  0.5f,  0.5f,
             0.5f,  0.5f,  0.5f,
            -0.5f,  0.5f,  0.5f,
            -0.5f,  0.5f, -0.5f
        };

        int _vertexBufferLightObject;
        int _vaoLamp;
        Shader _lampShader;
        Vector3 _lightPos = new Vector3(1.0f, 1.0f, 0.5f);

        // Camera ===================================================================================
        Camera _camera;
        bool _firstMove = true;
        Vector2 _lastPos;

        public window(GameWindowSettings gameWindowSettings, NativeWindowSettings nativeWindowSettings) : base(gameWindowSettings, nativeWindowSettings)
        {
            //park[0] = new asset3d();
            //park[1] = new asset3d();
            //park[2] = new asset3d();
            for (int i = 0; i < 10; i++)
            {
                park[i] = new asset3d();
            }
        }
        //public Matrix4 generateArbRotationMatrix(Vector3 axis, Vector3 center, float degree)
        //{
        //    var rads = MathHelper.DegreesToRadians(degree);

        //    var secretFormula = new float[4, 4]
        //    {
        //        { (float)Math.Cos(rads) + (float)Math.Pow(axis.X, 2) * (1 - (float)Math.Cos(rads)), axis.X * axis.Y * (1 - (float)Math.Cos(rads)) - axis.Z * (float)Math.Sin(rads),    axis.X * axis.Z * (1 - (float)Math.Cos(rads)) + axis.Y * (float)Math.Sin(rads),   0 },
        //        { axis.Y * axis.X * (1 - (float)Math.Cos(rads)) + axis.Z * (float)Math.Sin(rads),   (float)Math.Cos(rads) + (float)Math.Pow(axis.Y, 2) * (1 - (float)Math.Cos(rads)), axis.Y * axis.Z * (1 - (float)Math.Cos(rads)) - axis.X * (float)Math.Sin(rads),   0 },
        //        { axis.Z * axis.X * (1 - (float)Math.Cos(rads)) - axis.Y * (float)Math.Sin(rads),   axis.Z * axis.Y * (1 - (float)Math.Cos(rads)) + axis.X * (float)Math.Sin(rads),   (float)Math.Cos(rads) + (float)Math.Pow(axis.Z, 2) * (1 - (float)Math.Cos(rads)), 0 },
        //        { 0, 0, 0, 1}
        //    };


        //    var secretformulaMatrix = new Matrix4
        //    (
        //           new Vector4(secretFormula[0, 0], secretFormula[0, 1], secretFormula[0, 2], secretFormula[0, 3]),
        //           new Vector4(secretFormula[1, 0], secretFormula[1, 1], secretFormula[1, 2], secretFormula[1, 3]),
        //           new Vector4(secretFormula[2, 0], secretFormula[2, 1], secretFormula[2, 2], secretFormula[2, 3]),
        //           new Vector4(secretFormula[3, 0], secretFormula[3, 1], secretFormula[3, 2], secretFormula[3, 3])
        //    );

        //    return secretformulaMatrix;
        //}
        protected override void OnLoad()
        {
            base.OnLoad();
            _camera = new Camera(new Vector3(0, 0, 1.5f), Size.X / Size.Y);

            //  Warna Background
            GL.ClearColor(0f, 0.75f, 1.0f, 1.0f);
            GL.Enable(EnableCap.DepthTest);

            //Initialisasi Light Object
            _vertexBufferLightObject = GL.GenBuffer();
            GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferLightObject);
            GL.BufferData(BufferTarget.ArrayBuffer, _vertices.Length * sizeof(float), _vertices, BufferUsageHint.DynamicDraw);
            _lampShader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
                "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.frag");
            _vaoLamp = GL.GenVertexArray();
            GL.BindVertexArray(_vaoLamp);
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float),0);
            GL.EnableVertexAttribArray(0);



            // PARK OBJECT ================================================================

            //park[0].LoadObjFile("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/assets/surface.obj");
            //park[1].LoadObjFile("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/assets/pine_tree.obj");
            //park[2].LoadObjFile("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/assets/trunk.obj");
            //park[3].LoadObjFile("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/assets/bench.obj");

            string park1 = "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/assets/surface.obj";
            string park2 = "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/assets/brickwall.obj";

            //park[0].LoadObjFile("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/assets/surface.obj");
            //park[1].LoadObjFile("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/assets/brickwall.obj");
            //park[2].LoadObjFile("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/assets/pagar_lampu.obj");
            //park[3].LoadObjFile("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/assets/stonepath.obj");
            //park[4].LoadObjFile("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/assets/pine_lower.obj");
            //park[5].LoadObjFile("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/assets/pine_upper.obj");
            //park[6].LoadObjFile("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/assets/statue.obj");

            string d1 = "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/texture/grass.jpg";

            string s1 = "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/texture/brick.jpg";

            park[0].initialize(park1, d1, s1);
            park[1].initialize(park2, d1, s1);

            //// Surface ==============================================
            ////park[0].load2(Size.X, Size.Y);
            ////park[1].load2(Size.X, Size.Y);
            //park[2].load2(Size.X, Size.Y);
            //park[3].load2(Size.X, Size.Y);
            //park[4].load2(Size.X, Size.Y);
            //park[5].load2(Size.X, Size.Y);
            //park[6].load2(Size.X, Size.Y);
            //park[0].scale(0.1f);
            //park[0].translate(0f, -2f, 0f);

            //// Pine tree 1 ==========================================
            //park[1].load2(Size.X, Size.Y);
            //park[2].load2(Size.X, Size.Y);
            //park[1].translate(0.5f, 0f, 0f);
            //park[2].translate(0.5f, 0f, 0f);


            //// Bench ================================================ 
            //park[3].load2(Size.X, Size.Y);
            //park[3].translate(0f, -3f, 0f);
            //park[3].scale(0.04f);






















            Console.WriteLine("Project UTS - Grafika Komputer");
            Console.WriteLine("Project by : ");

            Console.WriteLine("1. VINCENTIUS SETYAWAN FUJIANTO - C14190150");
            Console.WriteLine("2. OLVIN YAURI - C14190200");
            Console.WriteLine("3. MICHAEL JONES SIHAN - C14190206");
            Console.WriteLine("Controls : ");
            Console.WriteLine("W / S - Move Baymax Up / Down");
            Console.WriteLine("O / P _ Shrink Baymax / Expand");
        }

        protected override void OnRenderFrame(FrameEventArgs args)
        {
            base.OnRenderFrame(args);

            GL.Clear(ClearBufferMask.ColorBufferBit|ClearBufferMask.DepthBufferBit);

            park[0].render2("moss green", 4, _camera.GetViewMatrix(), _camera.GetProjectionMatrix(), _lightPos, _camera.Position);
            park[1].render2("light grey", 4, _camera.GetViewMatrix(), _camera.GetProjectionMatrix(), _lightPos, _camera.Position);
            //park[2].render2("brown", 4, _camera.GetViewMatrix(), _camera.GetProjectionMatrix(), _lightPos, _camera.Position);
            //park[3].render2("light grey", 4, _camera.GetViewMatrix(), _camera.GetProjectionMatrix(), _lightPos, _camera.Position);
            //park[4].render2("brown", 4, _camera.GetViewMatrix(), _camera.GetProjectionMatrix(), _lightPos, _camera.Position);
            //park[5].render2("light green", 4, _camera.GetViewMatrix(), _camera.GetProjectionMatrix(), _lightPos, _camera.Position);
            //park[6].render2("light grey", 4, _camera.GetViewMatrix(), _camera.GetProjectionMatrix(), _lightPos, _camera.Position);





            _lampShader.Use();
            Matrix4 lampMatrix = Matrix4.CreateScale(0.25f);
            lampMatrix = lampMatrix * Matrix4.CreateTranslation(_lightPos);

            _lampShader.SetMatrix4("transform", lampMatrix);
            _lampShader.SetMatrix4("view", _camera.GetViewMatrix());
            _lampShader.SetMatrix4("projection", _camera.GetProjectionMatrix());

            GL.BindVertexArray(_vaoLamp);
            GL.DrawArrays(PrimitiveType.Triangles, 0, 36);

            SwapBuffers();

        }

        protected override void OnUpdateFrame(FrameEventArgs args)
        {
            base.OnUpdateFrame(args);

            var input = KeyboardState;
            if (input.IsKeyDown(Keys.Escape))
            {
                Close();
            }
            float cameraSpeed = 0.5f;
            if (input.IsKeyDown(Keys.W))
            {
                _camera.Position += _camera.Front * cameraSpeed * (float)args.Time;
            }
            if (input.IsKeyDown(Keys.A))
            {
                _camera.Position -= _camera.Right * cameraSpeed * (float)args.Time;
            }
            if (input.IsKeyDown(Keys.S))
            {
                _camera.Position -= _camera.Front * cameraSpeed * (float)args.Time;
            }
            if (input.IsKeyDown(Keys.D))
            {
                _camera.Position += _camera.Right * cameraSpeed * (float)args.Time;
            }
            if (input.IsKeyDown(Keys.Space))
            {
                _camera.Position += _camera.Up * cameraSpeed * (float)args.Time;
            }
            if (input.IsKeyDown(Keys.LeftControl))
            {
                _camera.Position -= _camera.Up * cameraSpeed * (float)args.Time;
            }
            var mouse = MouseState;
            var sensitivity = 0.2f;
            if (_firstMove)
            {
                _lastPos = new Vector2(mouse.X, mouse.Y);
                _firstMove = false;
            }
            else
            {
                var deltaX = mouse.X - _lastPos.X;
                var deltaY = mouse.Y - _lastPos.Y;
                _lastPos = new Vector2(mouse.X, mouse.Y);
                _camera.Yaw += deltaX * sensitivity;
                _camera.Pitch -= deltaY * sensitivity;
            }
        }

        protected override void OnResize(ResizeEventArgs e)
        {
            base.OnResize(e);

            GL.Viewport(0, 0, Size.X, Size.Y);
            _camera.AspectRatio = Size.X / (float)Size.Y;
        }

        protected override void OnKeyDown(KeyboardKeyEventArgs e)
        {
            base.OnKeyDown(e);
           
        }
    }
}
