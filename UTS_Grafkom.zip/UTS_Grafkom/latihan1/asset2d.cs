﻿using System;
using System.Collections.Generic;
using System.Text;
using LearnOpenTK.Common;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using OpenTK.Windowing.Common;

namespace latihan1
{
    class asset2d
    {
        //float[] _vertices =
        //{//x, y, z
        //-0.5f, -0.5f, 0.0f, //Kaki kiri segitiga
        //0.5f, -0.5f, 0.0f,   //Kaki kanan segitiga
        //0.0f, 0.5f, 0.0f    //Atas segitiga
        //};

        float[] _vertices =
        {

        };
        uint[] _indices =
        {

        };

       


        //  VBO
        int _vertexBufferObject;    //Mengurus variabel vertex ke GPU

        //  VAO
        int _vertexArrayObject;     //Mengurus terkait array vertex yang kita kirim

        int _elementBufferObject;

        Shader _shader;
        int indexs = 0;
        int[] _pascal = { };

        public asset2d(float[] vertices, uint[] indices)
        {
            _vertices = vertices;
            _indices = indices;
        }

        public void load(string color)
        {
            //  Create buffer
            _vertexBufferObject = GL.GenBuffer();

            //  Setting target dari buffer yang dituju  
            GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject);

            //  Kirim array vertex melalui Buffer ke GPU
            GL.BufferData(BufferTarget.ArrayBuffer, _vertices.Length * sizeof(float), _vertices, BufferUsageHint.StaticDraw);

            // Setinggan VAO :  
            _vertexArrayObject = GL.GenVertexArray();
            GL.BindVertexArray(_vertexArrayObject);

            //  Parameter 1 -> lokasi index input yg ada di shader
            //  Parameter 2 -> Jumlah elemen yg dikirimkan. Contoh yg ini 3 float untuk tiap vertex
            //  Parameter 3 -> Type data yg kita kirimkan berjenis apa
            //  Parameter 4 -> Apakah perlu di normalisasi? True or False
            //  Parameter 5 -> Jumlah vertex * sizeof(float)
            //  Parameter 6 -> Mulai dari index ke berapa?

            //  Vertices 1 color : 
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float), 0);

            // Vertices 3 color : 
            //GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 6 * sizeof(float), 0);

            //  Menyalakan / Enable variable index ke 0 yg ada pada shader
            GL.EnableVertexAttribArray(0);

            //  Settingan elemen buffer object
            if (_indices.Length != 0)
            {
                _elementBufferObject = GL.GenBuffer();
                GL.BindBuffer(BufferTarget.ElementArrayBuffer, _elementBufferObject);
                GL.BufferData(BufferTarget.ElementArrayBuffer, _indices.Length * sizeof(uint), _indices, BufferUsageHint.StaticDraw);
            }

            if (color == "black")
            {
                _shader = new Shader("C:/Users/Olvin Yauri/source/repos/latihan1/latihan1/Shader/shader.vert",
                               "C:/Users/Olvin Yauri/source/repos/latihan1/latihan1/Shader/black.frag");
                _shader.Use();
            }
            if (color == "white")
            {
                _shader = new Shader("C:/Users/Olvin Yauri/source/repos/latihan1/latihan1/Shader/shader.vert",
                               "C:/Users/Olvin Yauri/source/repos/latihan1/latihan1/Shader/white.frag");
                _shader.Use();
            }
            if (color == "grey")
            {
                _shader = new Shader("C:/Users/Olvin Yauri/source/repos/latihan1/latihan1/Shader/shader.vert",
                               "C:/Users/Olvin Yauri/source/repos/latihan1/latihan1/Shader/grey.frag");
                _shader.Use();
            }
            if (color == "street")
            {
                _shader = new Shader("C:/Users/Olvin Yauri/source/repos/latihan1/latihan1/Shader/shader.vert",
                               "C:/Users/Olvin Yauri/source/repos/latihan1/latihan1/Shader/street.frag");
                _shader.Use();
            }
        }

        public void render(int _lines)
        {
            //  Step menggambar sebuah objek
            //  1. Enable shader
            _shader.Use();

            //  Setting ganti warna dengan sistem variabel uniform
            //int vertexColorLocation = GL.GetUniformLocation(_shader.Handle, "ourColor");
            //GL.Uniform4(vertexColorLocation, 0.0f, 0.0f, 1.0f, 1.0f);

            //  2. Panggil bind VAO
            GL.BindVertexArray(_vertexArrayObject);

            //  3. Panggil fungsi untuk menggambar

            if (_indices.Length != 0)
            {
                //  Gambar element 
                GL.DrawElements(PrimitiveType.Triangles, _indices.Length, DrawElementsType.UnsignedInt, 0);
            }
            else
            {   // Gambar segitiga
                if (_lines == 0)
                {

                    GL.DrawArrays(PrimitiveType.Triangles, 0, 3);
                }
                else if (_lines == 1)
                {

                    GL.DrawArrays(PrimitiveType.LineStrip, 0, 3);
                }
                else if (_lines == 2)
                {

                    GL.DrawArrays(PrimitiveType.LineLoop, 0, 3);
                }
                else if (_lines == 3)
                {
                    //  Lingkaran tanpa isi
                    GL.DrawArrays(PrimitiveType.LineLoop, 0, (_vertices.Length + 1) / 3);

                    //  Lingkaran pakai isi
                    //GL.DrawArrays(PrimitiveType.TriangleFan, 0, (_vertices.Length + 1)/3);
                }
                else if (_lines == 4)
                {
                    GL.DrawArrays(PrimitiveType.LineStrip, 0, indexs);
                }
                else if (_lines == 5)
                {
                    GL.DrawArrays(PrimitiveType.LineStrip, 0, (_vertices.Length + 1) / 3);
                }

            }
        }
        public void createCircle(float center_x, float center_y, float radius)
        {
            _vertices = new float[1080];
            
            //  Looping buat mencari 360 titik untuk membuat lingkaran
            for (int i = 0; i < 360; i++)
            {
                //  Titik i dirubah menjadi radian untuk membuat alfa
                double deginRad = i * Math.PI / 180;

                //  Simpan x titik 1
                _vertices[i * 3] = (float)Math.Cos(deginRad) * radius + center_x;

                _vertices[i * 3 + 1] = (float)Math.Sin(deginRad) * radius + center_y;

                _vertices[i * 3 + 2] = 0;
            }
        }

        public void createEllips(float center_x, float center_y, float radius_x, float radius_y)
        {
            _vertices = new float[1080];

            //  Looping buat mencari 360 titik untuk membuat lingkaran
            for (int i = 0; i < 360; i++)
            {
                //  Titik i dirubah menjadi radian untuk membuat alfa
                double deginRad = i * Math.PI / 180;

                //  Simpan x titik 1
                _vertices[i * 3] = (float)Math.Cos(deginRad) * radius_x + center_x;

                _vertices[i * 3 + 1] = (float)Math.Sin(deginRad) * radius_y + center_y;

                _vertices[i * 3 + 2] = 0;
            }
        }
        
        public void updateMousePosition(float _x, float _y, float _z)
        {
            _vertices[indexs * 3] = _x;
            _vertices[indexs * 3 + 1] = _y;
            _vertices[indexs * 3 + 2] = _z;
            indexs++;

            GL.BufferData(BufferTarget.ArrayBuffer, indexs * 3 * sizeof(float), _vertices, BufferUsageHint.StaticDraw);

            // Setinggan VAO :  
            //_vertexArrayObject = GL.GenVertexArray();
            GL.BindVertexArray(_vertexArrayObject);

            //  Vertices 1 color : 
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float), 0);

            //  Menyalakan / Enable variable index ke 0 yg ada pada shader
            GL.EnableVertexAttribArray(0);
        }
        public List<float> CreateCurveBezier()
        {
            List<float> _vertices_bezier = new List<float>();
            List<int> pascal = getRow(indexs - 1);
            _pascal = pascal.ToArray();

            for (float t = 0; t <= 1.0f; t += 0.01f)
            {
                Vector2 p = getP(indexs, t);
                _vertices_bezier.Add(p.X);
                _vertices_bezier.Add(p.Y);
                _vertices_bezier.Add(0);
            }
            return _vertices_bezier;
        }
        public Vector2 getP(int n, float t)
        {
            Vector2 p = new Vector2(0, 0);
            float[] k = new float[n];

            for (int i = 0; i < n; i++)
            {
                k[i] = (float)Math.Pow((1 - t), n - 1 - i) * (float)Math.Pow(t, i) * _pascal[i];
            }
            for (int i = 0; i < n; i++)
            {
                p.X += k[i] * _vertices[i * 3];
                p.Y += k[i] * _vertices[i * 3 + 1];
            }
            return p;
        }
        public List<int> getRow(int rowIndex)
        {
            List<int> currow = new List<int>();

            //  Elemen 1 dari pascal
            currow.Add(1);

            if (rowIndex == 0)
            {
                return currow;
            }
            List<int> prev = getRow(rowIndex - 1);
            // Tambah element pascal yg di tengah
            for (int i = 1; i < prev.Count; i++)
            {
                int curr = prev[i - 1] + prev[i];
                currow.Add(curr);
            }
            //  Tambah element yg terakhir
            currow.Add(1);

            return currow;
        }
        public void setVertices(float[] vertices)
        {
            _vertices = vertices;
        }
        public bool getVerticesLength()
        {
            if (_vertices[0] == 0)
            {
                return false;
            }
            if ((_vertices.Length + 1) / 3 > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
