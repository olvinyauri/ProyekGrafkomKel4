﻿using System;
using OpenTK;
using OpenTK.Windowing.Desktop;

namespace latihan1
{
    class Program
    {
        static void Main(string[] args)
        {
            var nativeWindowSettings = new NativeWindowSettings()
            {
                Size = new OpenTK.Mathematics.Vector2i(1000,1000),
                Title = "UTS"
            };
            using (var window = new window(GameWindowSettings.Default, nativeWindowSettings))
            {
                window.Run();
            }
        }
    }
}
