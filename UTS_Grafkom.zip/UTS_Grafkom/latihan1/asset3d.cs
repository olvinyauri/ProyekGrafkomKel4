﻿using LearnOpenTK.Common;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace latihan1
{
    class asset3d
    {
        List<Vector3> _vertices = new List<Vector3>();
        List<Vector3> _textureVertices = new List<Vector3>();
        List<Vector3> _kombinasidata = new List<Vector3>();
        List<Vector3> _normals = new List<Vector3>();

        List<uint> _indices = new List<uint>();

        public List<asset3d> child = new List<asset3d>();

        //  VBO
        int _vertexBufferObject;    //Mengurus variabel vertex ke GPU

        //  VAO
        int _vertexArrayObject;     //Mengurus terkait array vertex yang kita kirim

        int _elementBufferObject;

        Shader _shader;

        Matrix4 transform = Matrix4.Identity;

        public Vector3 _centerPosition = new Vector3(0, 0, 0);
        public List<Vector3> _euler = new List<Vector3>();


        List<float> vertex = new List<float>();
        protected List<uint> vertexIndices = new List<uint>();
        protected List<uint> normalIndices = new List<uint>();
        protected List<Vector2> texture = new List<Vector2>();
        protected List<uint> textureIndices = new List<uint>();
        private Shader _lightingShader;

        public asset3d()
        {
            _euler.Add(new Vector3(1, 0, 0)); // Sumbu X
            _euler.Add(new Vector3(0, 1, 0)); // Sumbu Y
            _euler.Add(new Vector3(0, 0, 1)); // Sumbu Z
            
        }
        float[] _vertices2 =
        {
             // Position          Normal
            -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f, // Front face
             0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,
             0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,
             0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,
            -0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,
            -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,

            -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f, // Back face
             0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,
             0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,
             0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,
            -0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,
            -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,

            -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f, // Left face
            -0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,
            -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,
            -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,
            -0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,
            -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,

             0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f, // Right face
             0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,
             0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,
             0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,
             0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,
             0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,

            -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f, // Bottom face
             0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,
             0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,
             0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,
            -0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,
            -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,

            -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f, // Top face
             0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,
             0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,
             0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,
            -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,
            -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f
        };
        Texture _diffuseMap;
        Texture _specularMap;
        public void initialize(string p1, string diffuse, string specular)
        {
            transform = Matrix4.Identity;
            LoadObjFile(p1);
            for (int i = 0; i < vertexIndices.Count; i++)
            {
                int index = (int)vertexIndices[i];

                vertex.Add(_vertices[index].X);
                vertex.Add(_vertices[index].Y);
                vertex.Add(_vertices[index].Z);

                index = (int)normalIndices[i];

                vertex.Add(_normals[index].X);
                vertex.Add(_normals[index].Y);
                vertex.Add(_normals[index].Z);


                index = (int)textureIndices[i];

                vertex.Add(texture[index].X);
                vertex.Add(texture[index].Y);
            }

            _vertexArrayObject = GL.GenVertexArray();
            GL.BindVertexArray(_vertexArrayObject);

            _vertexBufferObject = GL.GenBuffer();
            GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject);
            GL.BufferData(BufferTarget.ArrayBuffer, vertex.Count * sizeof(float), vertex.ToArray(), BufferUsageHint.StaticDraw);


            _lightingShader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
                "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/lightning.frag");
            


            var vertexLocation = _lightingShader.GetAttribLocation("aPosition");
            GL.EnableVertexAttribArray(vertexLocation);
            GL.VertexAttribPointer(vertexLocation, 3, VertexAttribPointerType.Float, false, 8 * sizeof(float), 0);
            var normalLocation = _lightingShader.GetAttribLocation("aNormal");
            GL.EnableVertexAttribArray(normalLocation);
            GL.VertexAttribPointer(normalLocation, 3, VertexAttribPointerType.Float, false, 8 * sizeof(float), 3 * sizeof(float));
            var texCoordLocation = _lightingShader.GetAttribLocation("aTexCoords");
            GL.EnableVertexAttribArray(texCoordLocation);
            GL.VertexAttribPointer(texCoordLocation, 2, VertexAttribPointerType.Float, false, 8 * sizeof(float), 6 * sizeof(float));

            //_vaoLamp = GL.GenVertexArray();
            //GL.BindVertexArray(_vaoLamp);
            //vertexLocation = _lampShader.GetAttribLocation("aPosition");
            //GL.EnableVertexAttribArray(vertexLocation);
            //GL.VertexAttribPointer(vertexLocation, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float), 0);

            _diffuseMap = Texture.LoadFromFile(diffuse);
            _specularMap = Texture.LoadFromFile(specular);
            //transform *= Matrix4.CreateScale(scaleratio);

        }
        public void load(int size_x, int size_y)
        {
            //  Create buffer
            _vertexBufferObject = GL.GenBuffer();

            //  Setting target dari buffer yang dituju  
            GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject);

            //  Kirim array vertex melalui Buffer ke GPU
            GL.BufferData(BufferTarget.ArrayBuffer, _vertices.Count * Vector3.SizeInBytes, _vertices.ToArray(), BufferUsageHint.StaticDraw);

            // Setinggan VAO :  
            _vertexArrayObject = GL.GenVertexArray();
            GL.BindVertexArray(_vertexArrayObject);

            //  Vertices 1 color : 
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float), 0);

            //  Menyalakan / Enable variable index ke 0 yg ada pada shader
            GL.EnableVertexAttribArray(0);

            //  Settingan elemen buffer object
            if (_indices.Count != 0)
            {
                _elementBufferObject = GL.GenBuffer();
                GL.BindBuffer(BufferTarget.ElementArrayBuffer, _elementBufferObject);
                GL.BufferData(BufferTarget.ElementArrayBuffer, _indices.Count * sizeof(uint), _indices.ToArray(), BufferUsageHint.StaticDraw);
            }

            //if (color == "black")
            //{
            //    _shader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
            //                   "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/black.frag");
            //    _shader.Use();
            //}
            //if (color == "white")
            //{
            //    _shader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
            //                   "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/white.frag");
            //    _shader.Use();
            //}
            //if (color == "grey")
            //{
            //    _shader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
            //                   "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/grey.frag");
            //    _shader.Use();
            //}
            //if (color == "street")
            //{
            //    _shader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
            //                   "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/street.frag");
            //    _shader.Use();
            //}
            //if (color == "light grey")
            //{
            //    _shader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
            //                   "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/lightning.frag");
            //    _shader.Use();
            //}
            //if (color == "yellow")
            //{
            //    _shader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
            //                   "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/yellow.frag");
            //    _shader.Use();
            //}
            //if (color == "red")
            //{
            //    _shader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
            //                   "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/red.frag");
            //    _shader.Use();
            //}
            //if (color == "green")
            //{
            //    _shader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
            //                   "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/green.frag");
            //    _shader.Use();
            //}
            //if (color == "light green")
            //{
            //    _shader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
            //                   "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/light green.frag");
            //    _shader.Use();
            //}
            //if (color == "dark green")
            //{
            //    _shader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
            //                   "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/dark green.frag");
            //    _shader.Use();
            //}
            //if (color == "gold")
            //{
            //    _shader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
            //                   "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/gold.frag");
            //    _shader.Use();
            //}
            //if (color == "moss green")
            //{
            //    _shader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
            //                   "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/lightning.frag");
            //    _shader.Use();
            //}
            //if (color == "yellow")
            //{
            //    _shader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
            //                   "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/yellow.frag");
            //    _shader.Use();
            //}
            //if (color == "gray")
            //{
            //    _shader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
            //                   "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/gray.frag");
            //    _shader.Use();
            //}
            //if (color == "blue")
            //{
            //    _shader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
            //                   "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/blue.frag");
            //    _shader.Use();
            //}
            _shader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
                               "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/lightning.frag");
            _shader.Use();
        }
        public void load2(int size_x, int size_y)
        {
            //for (int i = 0; i < _indices.Count; i++)
            //{
            //    int index = (int)_indices[i];

            //    vertex.Add(_vertices[index].X);
            //    vertex.Add(_vertices[index].Y);
            //    vertex.Add(_vertices[index].Z);

            //    index = (int)normalIndices[i];

            //    vertex.Add(_normals[index].X);
            //    vertex.Add(_normals[index].Y);
            //    vertex.Add(_normals[index].Z);

            //    index = (int)textureIndices[i];

            //    vertex.Add(texture[index].X);
            //    vertex.Add(texture[index].Y);
            //}
            //    _vertexArrayObject = GL.GenVertexArray();
            //    GL.BindVertexArray(_vertexArrayObject);

            //    _vertexBufferObject = GL.GenBuffer();
            //    GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject);
            //    GL.BufferData(BufferTarget.ArrayBuffer, vertex.Count * sizeof(float), vertex.ToArray(), BufferUsageHint.StaticDraw);

            //    _lightingShader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
            //                     "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/lightning.frag");

            //    var vertexLocation = _lightingShader.GetAttribLocation("aPosition");
            //    GL.EnableVertexAttribArray(vertexLocation);
            //    GL.VertexAttribPointer(vertexLocation, 3, VertexAttribPointerType.Float, false, 8 * sizeof(float), 0);
            //    var normalLocation = _lightingShader.GetAttribLocation("aNormal");
            //    GL.EnableVertexAttribArray(normalLocation);
            //    GL.VertexAttribPointer(normalLocation, 3, VertexAttribPointerType.Float, false, 8 * sizeof(float), 3 * sizeof(float));
            //    var texCoordLocation = _lightingShader.GetAttribLocation("aTexCoords");
            //    GL.EnableVertexAttribArray(texCoordLocation);
            //    GL.VertexAttribPointer(texCoordLocation, 2, VertexAttribPointerType.Float, false, 8 * sizeof(float), 6 * sizeof(float));

            //    string diffuse = "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/texture/grass.jpg";
            //    string specular = "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/texture/brick.jpg";

            //    _diffuseMap = Texture.LoadFromFile(diffuse);
            //    _specularMap = Texture.LoadFromFile(specular);
            //    //_transform *= Matrix4.CreateScale(scaleratio);

            // =============================================================================================================================

            //_vertexBufferObject = GL.GenBuffer(); //create buffer
            //GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject); //setting target dari buffer yang dituju
            //GL.BufferData(BufferTarget.ArrayBuffer, _vertices.Count * sizeof(float), _vertices.ToArray(), BufferUsageHint.StaticDraw);

            ////SETTINGAN VAO
            //_vertexArrayObject = GL.GenVertexArray();
            //GL.BindVertexArray(_vertexArrayObject);

            ////SETINGAN CARA BACA BINARY
            ////DEFAULT
            //GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 6 * sizeof(float), 0);

            ////Menyalakan var index[0] (layout location=0) yg ada pd shader.vert DEFAULT
            //GL.EnableVertexAttribArray(0);
            //GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, 8 * sizeof(float), 3 * sizeof(float));
            //GL.EnableVertexAttribArray(1);

            //GL.VertexAttribPointer(2, 2, VertexAttribPointerType.Float, false, 8 * sizeof(float), 6 * sizeof(float));
            //GL.EnableVertexAttribArray(2);
            //// =============================================================================================

            _vertexBufferObject = GL.GenBuffer();

            //  Setting target dari buffer yang dituju  
            GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject);

            //  Kirim array vertex melalui Buffer ke GPU
            GL.BufferData(BufferTarget.ArrayBuffer, _vertices.Count * Vector3.SizeInBytes, _vertices.ToArray(), BufferUsageHint.StaticDraw);

            // Setinggan VAO :  
            _vertexArrayObject = GL.GenVertexArray();
            GL.BindVertexArray(_vertexArrayObject);

            //  Vertices 1 color : 
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float), 0);

            //  Menyalakan / Enable variable index ke 0 yg ada pada shader
            GL.EnableVertexAttribArray(0);

            //  Settingan elemen buffer object
            if (_indices.Count != 0)
            {
                _elementBufferObject = GL.GenBuffer();
                GL.BindBuffer(BufferTarget.ElementArrayBuffer, _elementBufferObject);
                GL.BufferData(BufferTarget.ElementArrayBuffer, _indices.Count * sizeof(uint), _indices.ToArray(), BufferUsageHint.StaticDraw);
            }
            _shader = new Shader("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/shader.vert",
                               "C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/lightning.frag");
            _shader.Use();
            _diffuseMap = Texture.LoadFromFile("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/texture/grass.jpg");
            _specularMap = Texture.LoadFromFile("C:/Users/Olvin Yauri/Desktop/Proyek Grafkom/UTS_Grafkom/latihan1/Shader/texture/grass.jpg");
        }
        public void render(int _lines, Matrix4 camera_view, Matrix4 camera_projection)
        {
            //  Step menggambar sebuah objek
            //  1. Enable shader
            //transform = transform * Matrix4.CreateTranslation(0f, 0f, 0.01f); //Transformasi posisi
            //transform = transform * Matrix4.CreateScale(1.001f);    // Transformasi ukuran
            //transform = transform * Matrix4.CreateRotationX(0.003f); // Transformasi rotasi sumbu X
            //transform = transform *  Matrix4.CreateRotationY(0.001f); // Transformasi rotasi sumbu Y
            //transform = transform * Matrix4.CreateRotationZ(0.005f); // Transformasi rotasi sumbu Z

            _shader.Use();

            _shader.SetMatrix4("transform", transform);
            _shader.SetMatrix4("view", camera_view);
            _shader.SetMatrix4("projection", camera_projection);

            
            _shader.SetVector3("objectColor", new Vector3(1.0f, 0.0f, 0.0f));
            _shader.SetVector3("lightColor", new Vector3(1.0f, 0.0f, 0.0f)); // Warna Cahaya


            //  Setting ganti warna dengan sistem variabel uniform
            //int vertexColorLocation = GL.GetUniformLocation(_shader.Handle, "ourColor");
            //GL.Uniform4(vertexColorLocation, 0.0f, 0.0f, 1.0f, 1.0f);

            //  2. Panggil bind VAO
            GL.BindVertexArray(_vertexArrayObject);

            //  3. Panggil fungsi untuk menggambar

            if (_indices.Count != 0)
            {
                //  Gambar element 
                GL.DrawElements(PrimitiveType.Triangles, _indices.Count, DrawElementsType.UnsignedInt, 0);
            }
            else
            {   // Gambar segitiga
                if (_lines == 0)
                {
                    GL.DrawArrays(PrimitiveType.Triangles, 0, _vertices.Count);
                }
                else if (_lines == 1)
                {

                    GL.DrawArrays(PrimitiveType.LineStripAdjacencyExt, 0, _vertices.Count);
                }
                else if (_lines == 2)
                {
                    GL.DrawArrays(PrimitiveType.LineLoop, 0, _vertices.Count);
                }
                else if (_lines == 3)
                {
                    //  Lingkaran tanpa isi
                    //GL.DrawArrays(PrimitiveType.LineLoop, 0, _vertices.Count);

                    //  Lingkaran pakai isi
                    GL.DrawArrays(PrimitiveType.TriangleFan, 0, (_vertices.Count + 1) / 3);
                }
            }
        }

        public void render2(string  color, int _lines, Matrix4 camera_view, Matrix4 camera_projection, Vector3 _lightPos, Vector3 _cameraPos)
        {
            _diffuseMap.Use(TextureUnit.Texture0);
            _specularMap.Use(TextureUnit.Texture1);

            _shader.Use();

            _shader.SetMatrix4("transform", transform);
            _shader.SetMatrix4("view", camera_view);
            _shader.SetMatrix4("projection", camera_projection);

            if (color == "light grey")
            {
                _shader.SetVector3("material.ambient", new Vector3(0.6f, 0.7f, 0.7f));
                _shader.SetVector3("material.diffuse", new Vector3(0.6f, 0.7f, 0.7f));
                _shader.SetVector3("material.specular", new Vector3(0.6f, 0.7f, 0.7f));
                _shader.SetFloat("material.shininess", 32f);
            }
            if (color == "moss green")
            {
                _shader.SetVector3("material.ambient", new Vector3(0.1f, 0.4f, 0.2f));
                _shader.SetVector3("material.diffuse", new Vector3(0.1f, 0.4f, 0.2f));
                _shader.SetVector3("material.specular", new Vector3(0.1f, 0.4f, 0.2f));
                _shader.SetFloat("material.shininess", 32f);
            }
            if (color == "light green")
            {
                _shader.SetVector3("material.ambient", new Vector3(0.0f, 0.9f, 0.5f));
                _shader.SetVector3("material.diffuse", new Vector3(0.0f, 0.9f, 0.5f));
                _shader.SetVector3("material.specular", new Vector3(0.0f, 0.9f, 0.5f));
                _shader.SetFloat("material.shininess", 32f);
            }
            //if (color == "brown")
            //{
            //    _shader.SetVector3("objectColor", new Vector3(0.5f, 0.2f, 0.0f));
            //    _shader.SetVector3("lightColor", new Vector3(1f, 1f, 1f));
            //}
            //_shader.SetVector3("lightPos", _lightPos);

            _shader.SetVector3("viewPos", _cameraPos);

            //tambah setting material
            //_shader.SetVector3("material.ambient", new Vector3(0.9f, 0.7f, 0.6f));
            //_shader.SetVector3("material.diffuse", new Vector3(0.9f, 0.7f, 0.6f));
            //_shader.SetVector3("material.specular", new Vector3(0.5f, 0.5f, 0.5f));
            //_shader.SetFloat("material.shininess", 32f);

            //tambah setting light
            _shader.SetVector3("light.ambient", new Vector3(0.2f));
            _shader.SetVector3("light.diffuse", new Vector3(0.5f));
            _shader.SetVector3("light.specular", new Vector3(1f));
            _shader.SetVector3("light.position", _lightPos);


            //  2. Panggil bind VAO
            GL.BindVertexArray(_vertexArrayObject);

            //  3. Panggil fungsi untuk menggambar

            if (_indices.Count != 0)
            {
                //  Gambar element 
                GL.DrawElements(PrimitiveType.Triangles, _indices.Count, DrawElementsType.UnsignedInt, 0);
            }
            else
            {   // Gambar segitiga
                if (_lines == 0)
                {
                    GL.DrawArrays(PrimitiveType.Triangles, 0, _vertices.Count);
                }
                else if (_lines == 1)
                {

                    GL.DrawArrays(PrimitiveType.LineStripAdjacencyExt, 0, _vertices.Count);
                }
                else if (_lines == 2)
                {
                    GL.DrawArrays(PrimitiveType.LineLoop, 0, _vertices.Count);
                }
                else if (_lines == 3)
                {
                    //  Lingkaran tanpa isi
                    //GL.DrawArrays(PrimitiveType.LineLoop, 0, _vertices.Count);

                    //  Lingkaran pakai isi
                    GL.DrawArrays(PrimitiveType.TriangleFan, 0, (_vertices.Count + 1) / 3);
                }
                else if (_lines == 4)
                {
                    GL.DrawArrays(PrimitiveType.Triangles, 0, 36);
                }
            }
        }
        internal void createCylinder2(float v1, float v2, float v3, float v4, float v5, int v6, int v7)
        {
            throw new NotImplementedException();
        }

        internal void LoadObjFile()
        {
            throw new NotImplementedException();
        }

        public void setVertices(List<Vector3> vertices)
        {
            _vertices = vertices;
        }
        public bool getVerticesLength()
        {
            if (_vertices.Count == 0)
            {
                return false;
            }
            if (_vertices.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void createBoxVertices(float x, float y, float z, float length)
        {
            _centerPosition.X = x;
            _centerPosition.Y = y;
            _centerPosition.Z = z;

            Vector3 temp_vector;

            //  Titik 1
            temp_vector.X = x - length / 2.0f;
            temp_vector.Y = y + length / 2.0f;
            temp_vector.Z = z - length / 2.0f;
            _vertices.Add(temp_vector); //  Simpan ke temp_vector

            //  Titik 2
            temp_vector.X = x + length / 2.0f;
            temp_vector.Y = y + length / 2.0f;
            temp_vector.Z = z - length / 2.0f;
            _vertices.Add(temp_vector);

            //  Titik 3
            temp_vector.X = x - length / 2.0f;
            temp_vector.Y = y - length / 2.0f;
            temp_vector.Z = z - length / 2.0f;
            _vertices.Add(temp_vector);

            //  Titik 4
            temp_vector.X = x + length / 2.0f;
            temp_vector.Y = y - length / 2.0f;
            temp_vector.Z = z - length / 2.0f;
            _vertices.Add(temp_vector);

            //  Titik 5
            temp_vector.X = x - length / 2.0f;
            temp_vector.Y = y + length / 2.0f;
            temp_vector.Z = z + length / 2.0f;
            _vertices.Add(temp_vector); //  Simpan ke temp_vector

            //  Titik 6
            temp_vector.X = x + length / 2.0f;
            temp_vector.Y = y + length / 2.0f;
            temp_vector.Z = z + length / 2.0f;
            _vertices.Add(temp_vector);

            //  Titik 7
            temp_vector.X = x - length / 2.0f;
            temp_vector.Y = y - length / 2.0f;
            temp_vector.Z = z + length / 2.0f;
            _vertices.Add(temp_vector);

            //  Titik 8
            temp_vector.X = x + length / 2.0f;
            temp_vector.Y = y - length / 2.0f;
            temp_vector.Z = z + length / 2.0f;
            _vertices.Add(temp_vector);

            _indices = new List<uint>
            {
                //  Segitiga depan 1
                0,1,2,
                //  Segitiga depan 2
                1,2,3,
                //  Segitiga atas 1
                0,4,5,
                //  Segitiga atas 2
                0,1,5,
                //  Segitiga kanan 1
                1, 3, 5,
                //  Segitiga kanan 2
                3,5,7,
                //  Segitiga kiri 1
                0,2,4,
                //  Segitiga kiri 2
                2,4,6,
                //  Segitiga belakang 1
                4,5,6,
                //  Segitiga belakang 2
                5,6,7,
                //  Segitiga bawah 1
                2,3,6,
                //  Segitiga bawah 2
                3,6,7
            };
        }

        public void createCuboid(float x, float y, float z, float lenX, float lenY, float lenZ)
        {
            _centerPosition.X = x;
            _centerPosition.Y = y;
            _centerPosition.Z = z;

            Vector3 temp_vector;

            //Titik 1
            temp_vector.X = x - lenX / 2.0f;
            temp_vector.Y = y + lenY / 2.0f;
            temp_vector.Z = z - lenZ / 2.0f;
            _vertices.Add(temp_vector);
            _normals.Add(temp_vector);

            //Titik 2
            temp_vector.X = x + lenX / 2.0f;
            temp_vector.Y = y + lenY / 2.0f;
            temp_vector.Z = z - lenZ / 2.0f;
            _vertices.Add(temp_vector);
            _normals.Add(temp_vector);

            //Titik 3
            temp_vector.X = x - lenX / 2.0f;
            temp_vector.Y = y - lenY / 2.0f;
            temp_vector.Z = z - lenZ / 2.0f;
            _vertices.Add(temp_vector);
            _normals.Add(temp_vector);

            //Titik 4
            temp_vector.X = x + lenX / 2.0f;
            temp_vector.Y = y - lenY / 2.0f;
            temp_vector.Z = z - lenZ / 2.0f;
            _vertices.Add(temp_vector);
            _normals.Add(temp_vector);

            //Titik 5
            temp_vector.X = x - lenX / 2.0f;
            temp_vector.Y = y + lenY / 2.0f;
            temp_vector.Z = z + lenZ / 2.0f;
            _vertices.Add(temp_vector);
            _normals.Add(temp_vector);

            //Titik 6
            temp_vector.X = x + lenX / 2.0f;
            temp_vector.Y = y + lenY / 2.0f;
            temp_vector.Z = z + lenZ / 2.0f;
            _vertices.Add(temp_vector);
            _normals.Add(temp_vector);

            //Titik 7
            temp_vector.X = x - lenX / 2.0f;
            temp_vector.Y = y - lenY / 2.0f;
            temp_vector.Z = z + lenZ / 2.0f;
            _vertices.Add(temp_vector);
            _normals.Add(temp_vector);

            //Titik 8
            temp_vector.X = x + lenX / 2.0f;
            temp_vector.Y = y - lenY / 2.0f;
            temp_vector.Z = z + lenZ / 2.0f;
            _vertices.Add(temp_vector);
            _normals.Add(temp_vector);

            _indices = new List<uint>
            {
                //Front
                0, 1, 2,
                1, 2, 3,
                
                //Top
                0, 4, 5,
                0, 1, 5,

                //Right
                1, 3, 5,
                3, 5, 7,

                //Left
                0, 2, 4,
                2, 4, 6,

                //Back
                4, 5, 6,
                5, 6, 7,

                //Bottom
                2, 3, 6,
                3, 6 ,7
            };
        }
        public void createEllipsoid(float radiusX, float radiusY, float radiusZ, float _x, float _y, float _z)
        {
            float pi = (float)Math.PI;
            Vector3 temp_vector;

            for (float u = -pi; u <= pi; u += pi / 1000)
            {
                for (float v = -pi / 2; v <= pi / 2; v += pi / 1000)
                {
                    temp_vector.X = _x + (float)Math.Cos(v) * (float)Math.Cos(u) * radiusX;
                    temp_vector.Y = _y + (float)Math.Cos(v) * (float)Math.Sin(u) * radiusY;
                    temp_vector.Z = _z + (float)Math.Sin(v) * radiusZ;
                    _vertices.Add(temp_vector);
                    Vector3 tempNormal = new Vector3(temp_vector - new Vector3(_x, _y, _z));
                    tempNormal.Normalize();
                    _normals.Add(tempNormal);
                }
            }
        }

        public void _createEllipsoid(float radiusX, float radiusY, float radiusZ, float _x, float _y, float _z)
        {
            _centerPosition.X = _x;
            _centerPosition.Y = _y;
            _centerPosition.Z = _z;

            float pi = (float)Math.PI;
            Vector3 temp_vector;
            for (float u = -pi; u <= pi; u += pi / 1000)
            {
                for (float v = -pi / 2; v <= pi / 2; v += pi / 1000)
                {
                    temp_vector.X = _x + (float)Math.Cos(v) * (float)Math.Cos(u) * radiusX;
                    temp_vector.Y = _y + (float)Math.Cos(v) * (float)Math.Sin(u) * radiusY;
                    temp_vector.Z = _z + (float)Math.Sin(v) * radiusX;
                    _vertices.Add(temp_vector);
                }
            }
        }
        public void createHyperboloid(float radiusX, float radiusY, float radiusZ, float _x, float _y, float _z)
        {
            float pi = (float)Math.PI;
            Vector3 temp_vector;
            float sec;
            for (float u = -pi; u <= pi; u += pi / 30)
            {
                for (float v = -pi / 2; v <= pi / 2; v += pi / 30)
                {
                    sec = 1.0f / (float)Math.Cos(v);
                    temp_vector.X = _x + sec * (float)Math.Cos(u) * radiusX;
                    temp_vector.Y = _y + sec * (float)Math.Sin(u) * radiusY;
                    temp_vector.Z = _z + (float)Math.Tan(v) * radiusZ;
                    _vertices.Add(temp_vector);
                }
            }
        }
        public void createEllipticCone(float radX, float radY, float radZ, float x, float y, float z)
        {
            float pi = (float)Math.PI;
            Vector3 temp_vector;
            for (float u = -pi; u <= pi; u += pi / 30)
            {
                for (float v = -pi / 2; v <= pi / 2; v += pi / 30)
                {
                    temp_vector.X = x + radX * v * (float)Math.Cos(u);
                    temp_vector.Z = y + radY * v * (float)Math.Sin(u);
                    temp_vector.Y = z + radZ * v;
                    _vertices.Add(temp_vector);
                }
            }
        }
        public void createEllipticParaboloid(float radX, float radY, float radZ, float x, float y, float z)
        {
            float pi = (float)Math.PI;
            Vector3 temp_vector;
            for (float u = -pi; u <= pi; u += pi / 300)
            {
                for (float v = 0; v <= pi; v += pi / 300)
                {
                    temp_vector.X = x + radX * v * (float)Math.Cos(u);
                    temp_vector.Z = y + radY * v * (float)Math.Sin(u);
                    temp_vector.Y = z + v * v;
                    _vertices.Add(temp_vector);
                }
            }
        }
        public void createEllipsoid2(float radiusX, float radiusY, float radiusZ, float _x, float _y, float _z, int sectorCount, int stackCount)
        {
            float pi = (float)Math.PI;
            Vector3 temp_vector;

            float sectorStep = 2 * (float)Math.PI / sectorCount;
            float stackStep = (float)Math.PI / stackCount;
            float sectorAngle, StackAngle, x, y, z;

            for (int i = 0; i < stackCount; ++i)
            {
                StackAngle = pi / 2 - i * stackStep;
                x = radiusX * (float)Math.Cos(StackAngle);
                y = radiusY * (float)Math.Cos(StackAngle);
                z = radiusZ * (float)Math.Sin(StackAngle);

                for (int j = 0; j <= sectorCount; ++j)
                {
                    sectorAngle = j * sectorStep;
                    temp_vector.X = x * (float)Math.Cos(sectorAngle);
                    temp_vector.Y = y * (float)Math.Sin(sectorAngle);
                    temp_vector.Z = z;
                    _vertices.Add(temp_vector);
                }
            }
            uint k1, k2;
            for (int i = 0; i < stackCount; ++i)
            {
                k1 = (uint)(i * (sectorCount + 1));
                k2 = (uint)(k1 + sectorCount + 1);
                for (int j = 0; j < sectorCount; ++j, ++k1, ++k2)
                {
                    if (i != 0)
                    {
                        _indices.Add(k1);
                        _indices.Add(k2);
                        _indices.Add(k1 + 1);
                    }
                    if (i != (stackCount - 1))
                    {
                        _indices.Add(k1 + 1);
                        _indices.Add(k2);
                        _indices.Add(k2 + 1);
                    }
                }
            }
        }

        public void createCylinder2(float x_, float y_, float z_, float radX, float height, float radZ, int sectorCount, int stackCount)
        {
            //rotationCenter.X = objectCenter.X = x_;
            //rotationCenter.Y = objectCenter.Y = y_;
            //rotationCenter.Z = objectCenter.Z = z_;

            float pi = (float)Math.PI;
            Vector3 temp_vector;
            stackCount = stackCount + 2;
            float sectorStep = 2 * pi / sectorCount;
            float sectorAngle, x, y, z;

            for (int j = 0; j <= sectorCount; ++j)
            {
                _vertices.Add(new Vector3(x_, y_ - height / 2, z_));
                _normals.Add(-Vector3.UnitY);
            }

            for (int i = 0; i <= stackCount; ++i)
            {
                x = radX;
                y = height * (i - 1) / (stackCount - 2) - height / 2;
                z = radZ;
                if (i != 0 && i != stackCount)
                {
                    for (int j = 0; j <= sectorCount; ++j)
                    {
                        sectorAngle = j * sectorStep;

                        temp_vector.X = x_ + x * (float)Math.Cos(sectorAngle);
                        temp_vector.Y = y_ + y;
                        temp_vector.Z = z_ + z * (float)Math.Sin(sectorAngle);

                        _vertices.Add(temp_vector);
                        _normals.Add(temp_vector);

                    }
                }
            }

            for (int j = 0; j <= sectorCount; ++j)
            {
                _vertices.Add(new Vector3(x_, y_ + height / 2, z_));
                _normals.Add(-Vector3.UnitY);
            }

            uint k1, k2;
            for (int i = 0; i < stackCount; ++i)
            {
                k1 = (uint)(i * (sectorCount + 1));
                k2 = (uint)(k1 + sectorCount + 1);

                for (int j = 0; j < sectorCount; ++j, ++k1, ++k2)
                {
                    if (i != 0)
                    {
                        _indices.Add(k1);
                        _indices.Add(k2);
                        _indices.Add(k1 + 1);

                    }

                    if (i != stackCount - 1)
                    {
                        _indices.Add(k1 + 1);
                        _indices.Add(k2);
                        _indices.Add(k2 + 1);
                    }
                }
            }
        }

        public void createCylinder3(float x_, float y_, float z_, float height, float topRad, float botRad, int sectorCount, int stackCount)
        {

            float pi = (float)Math.PI;
            Vector3 temp_vector;
            stackCount = stackCount + 2;
            float sectorStep = 2 * pi / sectorCount;
            float sectorAngle, x, y, z;

            for (int j = 0; j <= sectorCount; ++j)
            {
                _vertices.Add(new Vector3(x_, y_ - height / 2, z_));
            }

            for (int i = 0; i <= stackCount; ++i)
            {
                x = z = botRad + i * (topRad - botRad) / stackCount;
                y = height * (i - 1) / (stackCount - 2) - height / 2;
                if (i != 0 && i != stackCount)
                {
                    for (int j = 0; j <= sectorCount; ++j)
                    {
                        sectorAngle = j * sectorStep;

                        temp_vector.X = x_ + x * (float)Math.Cos(sectorAngle);
                        temp_vector.Y = y_ + y;
                        temp_vector.Z = z_ + z * (float)Math.Sin(sectorAngle);

                        _vertices.Add(temp_vector);
                    }
                }
            }

            for (int j = 0; j <= sectorCount; ++j)
            {
                _vertices.Add(new Vector3(x_, y_ + height / 2, z_));
            }

            uint k1, k2;
            for (int i = 0; i < stackCount; ++i)
            {
                k1 = (uint)(i * (sectorCount + 1));
                k2 = (uint)(k1 + sectorCount + 1);

                for (int j = 0; j < sectorCount; ++j, ++k1, ++k2)
                {
                    if (i != 0)
                    {
                        _indices.Add(k1);
                        _indices.Add(k2);
                        _indices.Add(k1 + 1);

                    }

                    if (i != stackCount - 1)
                    {
                        _indices.Add(k1 + 1);
                        _indices.Add(k2);
                        _indices.Add(k2 + 1);
                    }
                }
            }
        }

        public void LoadObjFile(string path_obj)
        {
            //komputer ngecek, apakah file bisa diopen atau tidak
            if (!File.Exists(path_obj))
            {
                //mengakhiri program dan kita kasih peringatan
                throw new FileNotFoundException("Unable to open \"" + path_obj + "\", does not exist.");
            }
            //lanjut ke sini
            using (StreamReader streamReader = new StreamReader(path_obj))
            {
                while (!streamReader.EndOfStream)
                {
                    //aku ngambil 1 baris tersebut -> dimasukkan ke dalam List string -> dengan di split pakai spasi
                    List<string> words = new List<string>(streamReader.ReadLine().ToLower().Split(' '));
                    //removeAll(kondisi dimana penghapusan terjadi)
                    words.RemoveAll(s => s == string.Empty);
                    //Melakukan pengecekkan apakah dalam satu list -> ada isinya atau tidak list nya tersebut
                    //kalau ada continue, perintah-perintah yang ada dibawahnya tidak akan dijalankan 
                    //dan dia bakal kembali keatas lagi / melanjutkannya whilenya
                    if (words.Count == 0)
                        continue;

                    //System.Console.WriteLine("New While");
                    //foreach (string x in words)
                    //               {
                    // System.Console.WriteLine("tes");
                    // System.Console.WriteLine(x);
                    //               }

                    string type = words[0];
                    //remove at -> menghapus data dalam suatu indexs dan otomatis data pada indeks
                    //berikutnya itu otomatis mundur kebelakang 1
                    words.RemoveAt(0);


                    switch (type)
                    {
                        // vertex
                        //parse merubah dari string ke tipe variabel yang diinginkan
                        //ada /10 karena saaat ini belum masuk materi camera
                        case "v":
                            _vertices.Add(new Vector3(float.Parse(words[0]) / 10, float.Parse(words[1]) / 10, float.Parse(words[2]) / 10));
                            break;

                        case "vt":
                            _textureVertices.Add(new Vector3(float.Parse(words[0]), float.Parse(words[1]),
                                                            words.Count < 3 ? 0 : float.Parse(words[2])));
                            break;

                        case "vn":
                            _normals.Add(new Vector3(float.Parse(words[0]), float.Parse(words[1]), float.Parse(words[2])));
                            break;
                        // face
                        case "f":
                            foreach (string w in words)
                            {
                                if (w.Length == 0)
                                    continue;

                                string[] comps = w.Split('/');

                                _indices.Add(uint.Parse(comps[0]) - 1);

                            }
                            break;

                        default:
                            break;
                    }
                }
            }

        }

        public void rotate(Vector3 pivot, Vector3 vector, float angle)
        {
            //Pivot -> mau rotate di titik mana
            //Vector -> mau rotate di sumbu apa? (sumbu x, y, z)
            //Angle -> rotatenya berapa derajat?

            angle = MathHelper.DegreesToRadians(angle);

            // Mulai rotasi
            for (int i = 0; i < _vertices.Count; i++)
            {
                _vertices[i] = getRotationResult(pivot, vector, angle, _vertices[i]);
            }
            //rotate the euler direction
            for (int i = 0; i < 3; i++)
            {
                _euler[i] = getRotationResult(pivot, vector, angle, _euler[i], true);
                // length = akar(x^2 + y^2 + z^2)
                // Normalize
                // Langkah - langkah
                float length = (float)Math.Pow(Math.Pow(_euler[i].X, 2.0f) + Math.Pow(_euler[i].Y, 2.0f) + Math.Pow(_euler[i].Z, 2.0f), 0.5f);
                Vector3 temporary = new Vector3(0, 0, 0);
                temporary.X = _euler[i].X / length;
                temporary.Y = _euler[i].Y / length;
                temporary.Z = _euler[i].Z / length;
                _euler[i] = temporary;

            }
            _centerPosition = getRotationResult(pivot, vector, angle, _centerPosition);
            GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject);
            GL.BufferData(BufferTarget.ArrayBuffer, _vertices.Count * Vector3.SizeInBytes, _vertices.ToArray(), BufferUsageHint.StaticDraw);
        }
        Vector3 getRotationResult(Vector3 pivot, Vector3 vector, float angle, Vector3 point, bool isEuler = false)
        {
            Vector3 temp, newPosition;

            if (isEuler)
            {
                temp = point;
            }
            else
            {
                temp = point - pivot;
            }
            newPosition.X =
                (float)temp.X * (float)(Math.Cos(angle) + Math.Pow(vector.X, 2.0f) * (1.0f - Math.Cos(angle))) +
                (float)temp.Y * (float)(vector.X * vector.Y * (1.0f - Math.Cos(angle)) - vector.Z * Math.Sin(angle)) +
                (float)temp.Z * (float)(vector.X * vector.Z * (1.0f - Math.Cos(angle)) + vector.Y * Math.Sin(angle));
            newPosition.Y =
                   (float)temp.X * (float)(vector.X * vector.Y * (1.0f - Math.Cos(angle)) + vector.Z * Math.Sin(angle)) +
                   (float)temp.Y * (float)(Math.Cos(angle) + Math.Pow(vector.Y, 2.0f) * (1.0f - Math.Cos(angle))) +
                   (float)temp.Z * (float)(vector.Y * vector.Z * (1.0f - Math.Cos(angle)) - vector.X * Math.Sin(angle));
            newPosition.Z =
                   (float)temp.X * (float)(vector.X * vector.Z * (1.0f - Math.Cos(angle)) - vector.Y * Math.Sin(angle)) +
                   (float)temp.Y * (float)(vector.Y * vector.Z * (1.0f - Math.Cos(angle)) + vector.X * Math.Sin(angle)) +
                   (float)temp.Z * (float)(Math.Cos(angle) + Math.Pow(vector.Z, 2.0f) * (1.0f - Math.Cos(angle)));
            if (isEuler)
            {
                temp = newPosition;
            }
            else
            {
                temp = newPosition + pivot;
            }
            return temp;
        }

        public void rotateloopleft()
        {
            transform = transform * Matrix4.CreateRotationZ(0.001f); // Transformasi rotasi sumbu Z
        }
        public void rotateloopright()
        {
            transform = transform * Matrix4.CreateRotationZ(-0.001f);
        }
        public void rotateX(float x)
        {
            transform = transform * Matrix4.CreateRotationX(MathHelper.DegreesToRadians(x));
            foreach (var asset3d in child)
            {
                asset3d.rotateX(x);
            }
        }
        public void rotateY(float x)
        {
            transform = transform * Matrix4.CreateRotationX(MathHelper.DegreesToRadians(x));
            foreach (var asset3d in child)
            {
                asset3d.rotateY(x);
            }
        }
        public void rotateZ(float x)
        {
            transform = transform * Matrix4.CreateRotationX(MathHelper.DegreesToRadians(x));
            foreach (var asset3d in child)
            {
                asset3d.rotateZ(x);
            }
        }
        public void scale(float x)
        {
            transform = transform * Matrix4.CreateTranslation(-1 * (_centerPosition)) * Matrix4.CreateScale(x) * Matrix4.CreateTranslation((_centerPosition));
        }
        public void _scale(float x)
        {
            transform = transform * Matrix4.CreateScale(x);
        }
        public void _translate(Vector3 position)
        {
            transform = transform * Matrix4.CreateTranslation(position);
            _centerPosition += position;
        }
        public void translate(float x, float y, float z)
        {
            transform = transform * Matrix4.CreateTranslation(x, y, z);
        }
        public void resetEuler()
        {
            _euler[0] = new Vector3(1, 0, 0);
            _euler[1] = new Vector3(0, 1, 0);
            _euler[2] = new Vector3(0, 0, 1);
        }
    }

}
